# Contoh-
Ayankku 😘
